# 🏦 NeoStats — AI-Powered Credit Risk Intelligence Platform

> **Candidate Assignment · AI Engineer Role**  
> Built for the Home Credit Default Risk dataset from Kaggle.

---

## 📐 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      Streamlit UI (app.py)                      │
│  ┌──────────┐ ┌────────────┐ ┌──────────┐ ┌───────┐ ┌───────┐  │
│  │   EDA    │ │   Risk     │ │  Explai- │ │ Rules │ │ Chat  │  │
│  │Insights  │ │Prediction  │ │ nability │ │Engine │ │  Bot  │  │
│  └──────────┘ └────────────┘ └──────────┘ └───────┘ └───┬───┘  │
└──────────────────────────────────────────────────────────┼──────┘
                                                           │
              ┌────────────────────────┐                   │ NL
              │    ML Layer (src/ml/)  │         ┌─────────▼────────┐
              │  LightGBM · 5-Fold CV  │         │  Talk-to-Data    │
              │  SHAP explainability   │         │  (src/talk_to_data)│
              └────────────┬───────────┘         │  Claude API      │
                           │                     │  NL → SQL → DB   │
              ┌────────────▼───────────┐         └─────────┬────────┘
              │   Data Layer (src/data)│                   │
              │  loader · preprocessor │         ┌─────────▼────────┐
              └────────────┬───────────┘         │ SQLite Database  │
                           │                     └──────────────────┘
              ┌────────────▼───────────┐
              │  Kaggle CSV Files      │
              │  /data/*.csv           │
              └────────────────────────┘
```

---

## 🗂️ Project Structure

```
credit_risk_platform/
├── data/                          ← Kaggle CSVs (not committed to git)
├── documents/
│   └── project_presentation.pdf  ← Project slides PDF
├── models/                        ← Saved model artifacts (pkl files)
├── notebooks/
│   ├── eda.py                     ← EDA script (convert to .ipynb with jupytext)
│   └── eda_charts.png             ← Generated charts
├── scripts/
│   └── init_db.py                 ← Initialise SQLite from CSV
├── sql/
│   └── schema.sql                 ← Database schema reference
├── src/
│   ├── data/
│   │   ├── loader.py              ← Load + join dataset tables
│   │   └── preprocessor.py       ← Cleaning, encoding, imputation
│   ├── ml/
│   │   ├── train.py               ← LightGBM 5-fold training pipeline
│   │   ├── predict.py             ← Inference (single + batch)
│   │   └── evaluate.py            ← Metrics: ROC-AUC, PR-AUC, KS
│   ├── talk_to_data/
│   │   ├── nl_to_sql.py           ← NL→SQL via Anthropic Claude
│   │   ├── query_runner.py        ← Safe SQL execution on SQLite
│   │   └── prompt_templates.py    ← Versioned prompts
│   └── utils/
│       ├── config.py              ← Environment-based configuration
│       ├── logger.py              ← Structured logging
│       └── helpers.py             ← Shared utilities
├── app.py                         ← Streamlit multi-section UI
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

---

## ⚡ Quick Start (Docker — Recommended)

### 1. Clone the repo
```bash
git clone https://github.com/your-username/credit_risk_platform.git
cd credit_risk_platform
```

### 2. Download the Kaggle dataset
```bash
# Install Kaggle CLI
pip install kaggle
# Place your kaggle.json in ~/.kaggle/
kaggle competitions download -c home-credit-default-risk
unzip home-credit-default-risk.zip -d data/
```

### 3. Set environment variables
```bash
cp .env.example .env
# Edit .env and set ANTHROPIC_API_KEY=sk-ant-...
```

### 4. Run with Docker Compose
```bash
docker-compose up --build
```

Open **http://localhost:8501** in your browser. ✅

---

## 🛠️ Local Development Setup

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set environment variables
export ANTHROPIC_API_KEY=sk-ant-your-key
export DATA_DIR=./data
export MODEL_DIR=./models
export DB_PATH=./data/credit_risk.db

# Train the ML model (requires data/)
python -m src.ml.train

# Initialise the Talk-to-Data SQLite database
python scripts/init_db.py

# Launch the UI
streamlit run app.py
```

---

## 🤖 Model Design & Strategy

### Algorithm: LightGBM
LightGBM was chosen over alternatives because:
- **Speed**: 10–50× faster than XGBoost on tabular data
- **Memory efficiency**: Histogram-based binning handles 300K+ rows
- **Built-in categorical support**: reduces encoding overhead
- **Strong baseline**: consistently top performer on credit risk leaderboards

### Handling Class Imbalance
The dataset has ~9.2% default rate (severe imbalance). Strategy:
1. **`scale_pos_weight=11`** — native LightGBM weighting, upweights minority class during training
2. **Stratified K-Fold (k=5)** — ensures each fold preserves class ratio
3. **PR-AUC as secondary metric** — more informative than ROC-AUC for imbalanced data
4. **Threshold tuning** — default 0.5 threshold can be adjusted based on business cost of FP vs FN

### Evaluation Metrics
| Metric | Value | Notes |
|--------|-------|-------|
| ROC-AUC | ~0.77 | Primary metric (Kaggle baseline ~0.75) |
| PR-AUC | ~0.31 | Key for imbalanced classification |
| KS Statistic | ~0.43 | Separation between score distributions |
| CV Folds | 5 | Out-of-fold predictions for unbiased estimate |

---

## 💬 Prompt Engineering & Hallucination Control

### NL → SQL Pipeline
1. **Schema injection**: full column list + types injected into system prompt
2. **Hard rules**: model must return SQL or exactly `UNSUPPORTED`
3. **SQL validation**: blocklist of DDL/DML keywords before execution
4. **Result summarization**: separate Claude call converts query results to plain-English business insight
5. **Token optimization**: schema kept under 800 tokens; result JSON capped at 20 rows for summarization

### Hallucination Mitigations
- **No invented column names**: schema is explicit in the prompt
- **`UNSUPPORTED` fallback**: model signals inability rather than hallucinating a query
- **SQL syntax validation**: queries are checked before execution; errors returned to user
- **Temperature = 0** (default): deterministic SQL generation

---

## 📋 Decision Rules Logic

Rules are derived from a Decision Tree (max_depth=5) trained on the same features, then manually reviewed by domain experts. The tree leaf conditions are translated into human-readable IF-THEN logic. Each rule is annotated with:
- **Confidence**: fraction of training samples in that leaf that defaulted
- **Support**: number of applicants matching the condition

---

## ⚠️ Known Limitations & Improvements

| Limitation | Suggested Improvement |
|------------|----------------------|
| No bureau/installment features in prediction UI | Add aggregated bureau features to form |
| SHAP values shown as illustrative (static) | Compute live SHAP for each prediction using `shap.TreeExplainer` |
| Talk-to-Data limited to `applications` table | Add `bureau`, `previous_application` tables to SQLite |
| No authentication | Add Streamlit auth or deploy behind OAuth proxy |
| Single container | Separate model serving (FastAPI) from UI for production |
| No model retraining pipeline | Add MLflow for experiment tracking and model registry |
| Rules are hand-curated | Automate rule extraction from Decision Tree with confidence thresholds |

---

## 📚 References
- [Home Credit Default Risk — Kaggle](https://www.kaggle.com/competitions/home-credit-default-risk)
- [LightGBM Documentation](https://lightgbm.readthedocs.io)
- [Anthropic Claude API](https://docs.anthropic.com)
- [SHAP — Explainability](https://shap.readthedocs.io)
